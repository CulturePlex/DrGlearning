Ext.define('DrGlearning.view.Loading', {
    extend: 'Ext.Panel',
	xtype: 'loading',
    config: {
        
        id: 'loadingpanel',
        fullscreen: true,
        style: 'background:transparent'
    }
});