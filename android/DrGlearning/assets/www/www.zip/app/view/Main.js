Ext.define('DrGlearning.view.Main', {
    extend: 'Ext.Container',
    requires: [
		'DrGlearning.view.CareersFrame',
		'DrGlearning.view.CareerFrame',
		'DrGlearning.view.Loading'
    ],

    config: {
        fullscreen: true,
        layout: 'fit'
    }

});