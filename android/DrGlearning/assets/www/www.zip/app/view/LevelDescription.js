Ext.define('DrGlearning.view.LevelDescription', {
   extend: 'Ext.Component',
    xtype: 'leveldescription',
    requires: ['Ext.XTemplate'],
    config: {
        cls: 'detail-card',
        styleHtmlContent: true,
        html: '<p>Aquí la descripción del nivel</p>'
        
    }
});