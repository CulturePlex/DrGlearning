Ext.define('DrGlearning.view.CareersListEmpty', {
    extend: 'Ext.Panel',
    xtype: 'careerslistempty',
	
	items:[
		{xtype:'button',
		text:'asdasd'}
		]
});
